using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)
$templatePath = $Request.Body.templatePath
$format = $Request.Body.format

$template = (Invoke-WebRequest -Uri $templatePath -UseBasicParsing).Content
if($format -eq 'json' -and $templatePath -like "*json") { $templateData = $template |ConvertFrom-Json} `
elseif($format -eq 'csv' -and $templatePath -like "*csv") { $templateData = $template |ConvertFrom-Csv} `
else {$result = @()}

if($templateData.count -gt 0){
    $row = $templateData[0]
    $names = $row.PSObject.Properties.Name

    #$result = $names|%{[ordered]@{
    #    Field = $_
    #    Values = @(($templateData|? $_ -ne ''|? $_ -ne $null).$_ | sort -Unique)
    #}}|? Values

    $temparray = @()
    foreach ($name in $names) {
    if ($name -notmatch 'TimeGenerated') {
        if ($templateData.$name -ne '' -and $templateData.$name -ne $null) {
        $temparray += @{Field = $name; Values = $templateData.$name}
        }  
    }
    }
    $result = $temparray | Sort-Object -Property Field
}


# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $result
})