using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)
$templatePath = $Request.Body.templatePath
$format = $Request.Body.format

$template = (Invoke-WebRequest -Uri $templatePath -UseBasicParsing).Content
$templateData = if($format -eq 'json') {$template |ConvertFrom-Json} else {$template |ConvertFrom-Csv}
$row = $templateData[0]
$names = $row.PSObject.Properties.Name

#$result = $names|%{[ordered]@{
#    Field = $_
#    Values = @(($templateData|? $_ -ne ''|? $_ -ne $null).$_ | sort -Unique)
#}}|? Values

$temparray = @()
foreach ($name in $names) {
  if ($name -notmatch 'TimeGenerated') {
    if ($templateData.$name -ne ''-or $templateData.$name -ne ''){
      $temparray += @{Field = $name; Values = $templateData.$name}
    }  
  }
}
$result = $temparray

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $result
})